package com.maxmod;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.util.Mth;

public class MaxModel extends EntityModel<LivingEntityRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(MaxMod.id("max"), "main");

	private final ModelPart head, rightArm, leftArm, rightLeg, leftLeg, tail;

	public MaxModel(ModelPart root) {
		super(root);
		this.head = root.getChild("head");
		this.rightArm = root.getChild("right_arm");
		this.leftArm = root.getChild("left_arm");
		this.rightLeg = root.getChild("right_leg");
		this.leftLeg = root.getChild("left_leg");
		this.tail = root.getChild("tail");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		PartDefinition head = root.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 0).addBox(-5F, -11F, -4F, 10F, 11F, 8F),
				PartPose.offset(0F, 10F, 0F));
		head.addOrReplaceChild("right_ear",
				CubeListBuilder.create().texOffs(28, 34).addBox(-3F, -1.5F, -0.5F, 3F, 3F, 1F),
				PartPose.offset(-5F, -9F, 0F));
		head.addOrReplaceChild("left_ear",
				CubeListBuilder.create().texOffs(28, 34).addBox(0F, -1.5F, -0.5F, 3F, 3F, 1F),
				PartPose.offset(5F, -9F, 0F));

		root.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(0, 20).addBox(-4F, 0F, -2F, 8F, 7F, 4F),
				PartPose.offset(0F, 10F, 0F));
		root.addOrReplaceChild("collar",
				CubeListBuilder.create().texOffs(26, 20).addBox(-3.5F, -1F, -2.5F, 7F, 2F, 5F),
				PartPose.offset(0F, 10F, 0F));

		root.addOrReplaceChild("right_arm",
				CubeListBuilder.create().texOffs(0, 34).addBox(-3F, -1F, -1.5F, 3F, 7F, 3F),
				PartPose.offset(-4F, 11F, 0F));
		root.addOrReplaceChild("left_arm",
				CubeListBuilder.create().texOffs(0, 34).addBox(0F, -1F, -1.5F, 3F, 7F, 3F),
				PartPose.offset(4F, 11F, 0F));

		root.addOrReplaceChild("right_leg",
				CubeListBuilder.create().texOffs(14, 34).addBox(-1.5F, 0F, -1.5F, 3F, 7F, 3F),
				PartPose.offset(-2F, 17F, 0F));
		root.addOrReplaceChild("left_leg",
				CubeListBuilder.create().texOffs(14, 34).addBox(-1.5F, 0F, -1.5F, 3F, 7F, 3F),
				PartPose.offset(2F, 17F, 0F));

		root.addOrReplaceChild("tail",
				CubeListBuilder.create().texOffs(38, 34).addBox(-0.5F, -0.5F, 0F, 1F, 1F, 7F),
				PartPose.offsetAndRotation(0F, 16.5F, 2F, 0.9F, 0F, 0F));

		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(LivingEntityRenderState state) {
		super.setupAnim(state);
		float deg = (float) Math.PI / 180F;
		head.yRot = state.yRot * deg;
		head.xRot = state.xRot * deg;
		float pos = state.walkAnimationPos;
		float speed = state.walkAnimationSpeed;
		rightLeg.xRot = Mth.cos(pos * 0.6662F) * 1.4F * speed;
		leftLeg.xRot = Mth.cos(pos * 0.6662F + (float) Math.PI) * 1.4F * speed;
		rightArm.xRot = Mth.cos(pos * 0.6662F + (float) Math.PI) * speed;
		leftArm.xRot = Mth.cos(pos * 0.6662F) * speed;
		tail.yRot = Mth.cos(state.ageInTicks * 0.15F) * 0.25F;
	}
}
