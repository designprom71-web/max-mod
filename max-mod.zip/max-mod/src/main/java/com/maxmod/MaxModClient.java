package com.maxmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;

public class MaxModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ModelLayerRegistry.registerModelLayer(MaxModel.LAYER, MaxModel::createBodyLayer);
		EntityRendererRegistry.register(MaxMod.MAX, MaxRenderer::new);
	}
}
