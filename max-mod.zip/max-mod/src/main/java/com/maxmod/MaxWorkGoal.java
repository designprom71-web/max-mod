package com.maxmod;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/** งานของ Max: ถือขวาน = ตัดต้นไม้, ถือที่ขุด = ขุดแร่ที่เลือก (ต้องอยู่โหมดทำงาน) */
public class MaxWorkGoal extends Goal {
	private static final int JOB_NONE = 0, JOB_LOGS = 1, JOB_ORE = 2;

	private final MaxEntity max;
	private final Set<Long> skipped = new HashSet<>();
	private BlockPos target;
	private int cooldown;
	private int breakTimer;
	private int stuck;

	public MaxWorkGoal(MaxEntity max) {
		this.max = max;
		this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
	}

	private int job() {
		ItemStack s = max.getMainHandItem();
		if (s.is(ItemTags.AXES)) return JOB_LOGS;
		if (s.is(ItemTags.PICKAXES) && !max.getOreKey().isEmpty()) return JOB_ORE;
		return JOB_NONE;
	}

	@Override
	public boolean canUse() {
		if (!max.isTame() || !max.isWorkMode() || max.isOrderedToSit() || job() == JOB_NONE) return false;
		LivingEntity owner = max.getOwner();
		if (owner == null || max.distanceToSqr(owner) > 24 * 24) return false;
		if (--cooldown > 0) return false;
		cooldown = 20;
		target = find(owner);
		return target != null;
	}

	@Override
	public boolean canContinueToUse() {
		LivingEntity owner = max.getOwner();
		return target != null && owner != null && max.isWorkMode() && job() != JOB_NONE
				&& stuck < 200 && max.distanceToSqr(owner) <= 28 * 28 && isValid(target);
	}

	@Override
	public void start() {
		breakTimer = 0;
		stuck = 0;
	}

	@Override
	public void stop() {
		if (target != null && stuck >= 200) skipped.add(target.asLong());
		target = null;
		max.getNavigation().stop();
	}

	@Override
	public boolean requiresUpdateEveryTick() {
		return true;
	}

	@Override
	public void tick() {
		if (target == null) return;
		double cx = target.getX() + 0.5, cy = target.getY() + 0.5, cz = target.getZ() + 0.5;
		max.getLookControl().setLookAt(cx, cy, cz);
		if (max.distanceToSqr(cx, cy, cz) > 12.25) { // ไกลกว่า ~3.5 บล็อก เดินเข้าไป
			stuck++;
			breakTimer = 0;
			if (max.getNavigation().isDone() || stuck % 20 == 0) {
				max.getNavigation().moveTo(cx, target.getY(), cz, 1.1);
			}
		} else {
			max.getNavigation().stop();
			breakTimer++;
			if (breakTimer % 5 == 0) max.swing(InteractionHand.MAIN_HAND);
			if (breakTimer >= 15) breakTarget();
		}
	}

	private void breakTarget() {
		if (!(max.level() instanceof ServerLevel level) || target == null) return;
		int job = job();
		if (job != JOB_NONE && matches(target, job)) {
			BlockState state = level.getBlockState(target);
			ItemStack tool = max.getMainHandItem();
			if (job == JOB_ORE && state.requiresCorrectToolForDrops() && !tool.isCorrectToolForDrops(state)) {
				skipped.add(target.asLong()); // ที่ขุดไม่แรงพอสำหรับแร่นี้
			} else {
				// ตัดทั้งต้น / ขุดทั้งเส้นแร่ที่ติดกัน
				for (BlockPos p : collect(target, job)) {
					if (max.getMainHandItem().isEmpty()) break; // เครื่องมือพังแล้ว
					level.destroyBlock(p, true, max);
					max.getMainHandItem().hurtAndBreak(1, max, EquipmentSlot.MAINHAND);
				}
			}
		}
		target = null;
	}

	/** รวมบล็อกชนิดเดียวกันที่ติดกัน (รวมทแยง) เริ่มจากบล็อกเป้าหมาย */
	private List<BlockPos> collect(BlockPos start, int job) {
		int cap = job == JOB_LOGS ? 160 : 64;
		List<BlockPos> result = new ArrayList<>();
		Set<Long> seen = new HashSet<>();
		ArrayDeque<BlockPos> queue = new ArrayDeque<>();
		queue.add(start);
		seen.add(start.asLong());
		while (!queue.isEmpty() && result.size() < cap) {
			BlockPos cur = queue.poll();
			result.add(cur);
			for (int dx = -1; dx <= 1; dx++) {
				for (int dy = -1; dy <= 1; dy++) {
					for (int dz = -1; dz <= 1; dz++) {
						if (dx == 0 && dy == 0 && dz == 0) continue;
						BlockPos n = cur.offset(dx, dy, dz);
						if (seen.add(n.asLong()) && matches(n, job)) queue.add(n);
					}
				}
			}
		}
		return result;
	}

	private boolean isValid(BlockPos p) {
		return matches(p, job());
	}

	private boolean matches(BlockPos p, int job) {
		BlockState s = max.level().getBlockState(p);
		if (job == JOB_LOGS) {
			return s.is(BlockTags.LOGS) && isNaturalLog(p);
		}
		if (job == JOB_ORE) {
			String k = MaxEntity.oreKeyOfBlock(s.getBlock());
			return k != null && k.equals(max.getOreKey());
		}
		return false;
	}

	/** ตัดเฉพาะต้นไม้ธรรมชาติ: ลำต้นต้องตั้งอยู่บนดิน ไม่ตัดบ้านไม้ซุงที่สร้างบนหิน/พื้นอื่น */
	private boolean isNaturalLog(BlockPos p) {
		BlockPos.MutableBlockPos m = p.mutable();
		while (max.level().getBlockState(m).is(BlockTags.LOGS)) m.move(Direction.DOWN);
		return max.level().getBlockState(m).is(BlockTags.DIRT);
	}

	private BlockPos find(LivingEntity owner) {
		BlockPos c = owner.blockPosition();
		boolean logs = job() == JOB_LOGS;
		int r = logs ? 10 : 8;
		int down = logs ? 4 : 8;
		int up = logs ? 12 : 8;
		BlockPos best = null;
		double bestDist = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.betweenClosed(c.offset(-r, -down, -r), c.offset(r, up, r))) {
			if (skipped.contains(p.asLong()) || !isValid(p)) continue;
			double d = max.distanceToSqr(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5);
			if (d < bestDist) {
				bestDist = d;
				best = p.immutable();
			}
		}
		if (skipped.size() > 64) skipped.clear();
		return best;
	}
}
