package com.maxmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;

public class MaxMod implements ModInitializer {
	public static final String MOD_ID = "maxmod";
	private static final String VILLAGER_CHECKED_TAG = "maxmod_checked";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	public static final ResourceKey<EntityType<?>> MAX_KEY = ResourceKey.create(Registries.ENTITY_TYPE, id("max"));
	public static final EntityType<MaxEntity> MAX = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, MAX_KEY,
			EntityType.Builder.of(MaxEntity::new, MobCategory.CREATURE)
					.sized(0.6F, 1.6F)
					.clientTrackingRange(8)
					.build(MAX_KEY));

	public static final ResourceKey<Item> EGG_KEY = ResourceKey.create(Registries.ITEM, id("max_spawn_egg"));
	public static final Item MAX_SPAWN_EGG = Registry.register(
			BuiltInRegistries.ITEM, EGG_KEY,
			new SpawnEggItem(new Item.Properties().setId(EGG_KEY).spawnEgg(MAX)));

	@Override
	public void onInitialize() {
		FabricDefaultAttributeRegistry.register(MAX, MaxEntity.createAttributes());

		// ไข่เกิดในแท็บ Spawn Eggs ของโหมดครีเอทีฟ
		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.SPAWN_EGGS)
				.register(output -> output.accept(MAX_SPAWN_EGG));

		// Max เกิดเฉพาะในหมู่บ้าน: เมื่อชาวบ้านโหลดเข้าโลกครั้งแรก มีโอกาส 1/3 ที่จะมี Max อยู่ข้างๆ
		// (ชาวบ้านมีเฉพาะในหมู่บ้านทุกไบโอม) เช็กครั้งเดียวต่อชาวบ้านด้วยแท็ก จึงไม่เกิดซ้ำ
		ServerEntityEvents.ENTITY_LOAD.register((Entity entity, ServerLevel level) -> {
			if (!BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).getPath().equals("villager")) return;
			if (!entity.addTag(VILLAGER_CHECKED_TAG)) return; // เช็กแล้วครั้งหนึ่ง ไม่ซ้ำ
			if (level.getRandom().nextInt(3) != 0) return;
			level.getServer().execute(() -> {
				if (entity.isRemoved()) return;
				int nearby = level.getEntitiesOfClass(MaxEntity.class, entity.getBoundingBox().inflate(48.0)).size();
				if (nearby >= 2) return;
				Entity spawned = MAX.spawn(level, entity.blockPosition(), EntitySpawnReason.NATURAL);
				if (spawned instanceof MaxEntity max) {
					max.setPersistenceRequired();
				}
			});
		});
	}
}
