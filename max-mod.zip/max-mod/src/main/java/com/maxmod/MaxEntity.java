package com.maxmod;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

public class MaxEntity extends TamableAnimal {
	public static final int MODE_FOLLOW = 0;
	public static final int MODE_WORK = 1;
	public static final int MODE_STAY = 2;

	private int mode = MODE_FOLLOW;
	private String oreKey = "";

	public MaxEntity(EntityType<? extends TamableAnimal> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 20.0) // เลือด 20 หน่วย (10 หัวใจ)
				.add(Attributes.MOVEMENT_SPEED, 0.3)
				.add(Attributes.ATTACK_DAMAGE, 2.0);
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new StayGoal(this));
		this.goalSelector.addGoal(2, new MaxWorkGoal(this));
		this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.1, true));
		this.goalSelector.addGoal(5, new FollowOwnerGoal(this, 1.1, 6.0F, 2.0F));
		this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8));
		this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 6.0F));
		this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));

		this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
		this.targetSelector.addGoal(3, new GuardTargetGoal(this));
	}

	/** โหมดอยู่เฉยๆ: ยืนนิ่งไม่เดิน */
	private static class StayGoal extends Goal {
		private final MaxEntity max;

		StayGoal(MaxEntity max) {
			this.max = max;
			this.setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP));
		}

		@Override
		public boolean canUse() {
			return max.isTame() && max.isOrderedToSit() && !max.isInWater();
		}

		@Override
		public void start() {
			max.getNavigation().stop();
		}
	}

	/** ถือดาบ + โหมดทำงาน = ช่วยสู้มอนสเตอร์รอบตัว */
	private static class GuardTargetGoal extends NearestAttackableTargetGoal<Monster> {
		private final MaxEntity max;

		GuardTargetGoal(MaxEntity max) {
			super(max, Monster.class, true);
			this.max = max;
		}

		@Override
		public boolean canUse() {
			return max.isTame() && max.isWorkMode() && max.holdingSword()
					&& !max.isOrderedToSit() && super.canUse();
		}
	}

	// ---------- อาหาร: ไก่สุกอย่างเดียว ----------
	@Override
	public boolean isFood(ItemStack stack) {
		return stack.is(Items.COOKED_CHICKEN);
	}

	@Override
	public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
		return null; // ไม่ขยายพันธุ์
	}

	// ---------- การโต้ตอบ ----------
	@Override
	public InteractionResult mobInteract(Player player, InteractionHand hand) {
		ItemStack held = player.getItemInHand(hand);
		Level lvl = this.level();

		// ไก่สุก: เลี้ยงให้เชื่อง / เติมเลือด
		if (held.is(Items.COOKED_CHICKEN)) {
			if (!isTame()) {
				if (!lvl.isClientSide()) {
					if (!player.getAbilities().instabuild) held.shrink(1);
					if (this.random.nextInt(3) == 0) {
						this.tame(player);
						this.navigation.stop();
						this.setTarget(null);
						lvl.broadcastEntityEvent(this, (byte) 7);
					} else {
						lvl.broadcastEntityEvent(this, (byte) 6);
					}
				}
				return InteractionResult.SUCCESS;
			}
			if (isOwnedBy(player) && getHealth() < getMaxHealth()) {
				if (!lvl.isClientSide()) {
					if (!player.getAbilities().instabuild) held.shrink(1);
					this.heal(6.0F);
				}
				return InteractionResult.SUCCESS;
			}
			return InteractionResult.PASS;
		}

		if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
		if (!isTame() || !isOwnedBy(player)) return InteractionResult.PASS;

		if (!held.isEmpty()) {
			String key = oreKeyOfStack(held);
			if (key != null) { // ถือบล็อกแร่ = กำหนดแร่ที่ให้ขุด
				if (!lvl.isClientSide()) {
					this.oreKey = key;
					msg(player, "Max จะขุดแร่: " + key);
				}
				return InteractionResult.SUCCESS;
			}
			if (isTool(held)) { // ให้เครื่องมือ
				if (!lvl.isClientSide()) {
					ItemStack current = this.getMainHandItem();
					ItemStack given = held.copyWithCount(1);
					if (!player.getAbilities().instabuild) held.shrink(1);
					if (!current.isEmpty() && !player.addItem(current)) player.drop(current, false);
					this.setItemSlot(EquipmentSlot.MAINHAND, given);
					this.setDropChance(EquipmentSlot.MAINHAND, 1.0F);
					msg(player, "Max ถือ " + given.getHoverName().getString());
				}
				return InteractionResult.SUCCESS;
			}
			return InteractionResult.PASS;
		}

		// มือเปล่า
		if (!lvl.isClientSide()) {
			if (player.isShiftKeyDown()) { // ย่อ + คลิกขวา = เอาเครื่องมือคืน
				ItemStack current = this.getMainHandItem();
				if (!current.isEmpty()) {
					if (!player.addItem(current.copy())) player.drop(current.copy(), false);
					this.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
					msg(player, "Max คืนเครื่องมือให้แล้ว");
				}
			} else { // คลิกขวา = สลับโหมด ตาม -> ทำงาน -> อยู่เฉยๆ
				setMode((mode + 1) % 3);
				String[] names = {"ตามผู้เล่น", "ทำงาน (ตัดไม้ / ขุดแร่ / ช่วยสู้)", "อยู่เฉยๆ"};
				msg(player, "Max: " + names[mode]);
			}
		}
		return InteractionResult.SUCCESS;
	}

	private static void msg(Player player, String text) {
		if (player instanceof ServerPlayer sp) {
			sp.sendSystemMessage(Component.literal(text), true);
		}
	}

	private static boolean isTool(ItemStack s) {
		return s.is(ItemTags.AXES) || s.is(ItemTags.SWORDS) || s.is(ItemTags.PICKAXES);
	}

	private void setMode(int newMode) {
		this.mode = newMode;
		boolean sit = newMode == MODE_STAY;
		this.setOrderedToSit(sit);
		this.setInSittingPose(sit);
	}

	// ---------- ข้อมูลสำหรับ Goal ----------
	public boolean isWorkMode() { return mode == MODE_WORK; }
	public String getOreKey() { return oreKey; }
	public boolean holdingSword() { return getMainHandItem().is(ItemTags.SWORDS); }

	public static String oreKeyOfBlock(Block block) {
		String p = BuiltInRegistries.BLOCK.getKey(block).getPath();
		if (p.equals("ancient_debris")) return p;
		if (!p.endsWith("_ore")) return null;
		return p.replace("deepslate_", "").replace("nether_", "").replace("_ore", "");
	}

	private static String oreKeyOfStack(ItemStack s) {
		if (s.getItem() instanceof BlockItem bi) return oreKeyOfBlock(bi.getBlock());
		return null;
	}

	@Override
	public boolean removeWhenFarAway(double distance) {
		return false;
	}

	// ---------- บันทึก / โหลด ----------
	@Override
	protected void addAdditionalSaveData(ValueOutput out) {
		super.addAdditionalSaveData(out);
		out.putInt("MaxMode", mode);
		out.putString("MaxOre", oreKey);
	}

	@Override
	protected void readAdditionalSaveData(ValueInput in) {
		super.readAdditionalSaveData(in);
		this.mode = in.getIntOr("MaxMode", MODE_FOLLOW);
		this.oreKey = in.getStringOr("MaxOre", "");
	}
}
