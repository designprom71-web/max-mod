package com.maxmod;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class MaxRenderer extends MobRenderer<MaxEntity, LivingEntityRenderState, MaxModel> {
	private static final Identifier TEXTURE = MaxMod.id("textures/entity/max.png");

	public MaxRenderer(EntityRendererProvider.Context context) {
		super(context, new MaxModel(context.bakeLayer(MaxModel.LAYER)), 0.4F);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public Identifier getTextureLocation(LivingEntityRenderState state) {
		return TEXTURE;
	}
}
